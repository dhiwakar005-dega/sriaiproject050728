import { useState } from 'react'
import './App.css'

function App() {
  const [started, setStarted] = useState(false)
  const [message, setMessage] = useState('')
  const [messages, setMessages] = useState<string[]>([])

  // BOT MESSAGE
  const addBotMessage = (text: string) => {
    setMessages(prev => [...prev, `SRI AI: ${text}`])

    if ('speechSynthesis' in window) {
      const speech = new SpeechSynthesisUtterance(text)
      speech.lang = 'ta-IN'
      speech.rate = 0.9
      window.speechSynthesis.speak(speech)
    }
  }

  // START ASSISTANT
  const startAssistant = () => {
    setStarted(true)
    setMessages([
      'Vanakkam akka! 👋 Naan SRI AI.',
      'Ungalukku education, job, health, financial help matrum government services pathi guide panren.',
      'Keela irukkura options-la ungalukku thevaiyana help-ai choose pannunga.'
    ])
  }

  // EDUCATION
  const showEducation = () => {
    addBotMessage(
      'Ungalukku education-la enna help venum akka? Scholarship venuma, higher studies continue pannanuma, illa course training venuma?'
    )
  }

  // JOBS
  const showJobs = () => {
    addBotMessage(
      'Ungalukku enna help venum akka? Pudhu skill kathukkanuma, job thedanuma, illa self-employment start pannanuma?'
    )
  }

  // FINANCIAL HELP
  const showFinancialHelp = () => {
    addBotMessage(
      'Ungalukku enna financial help venum akka? Government financial assistance venuma, small business start panna help venuma, illa education fees-ku help venuma?'
    )
  }

  // HEALTH
  const showHealth = () => {
    addBotMessage(
      'Ungalukku enna health-related help venum akka? Government hospital services, health scheme details, illa pregnancy and child care information venuma?'
    )
  }

  // HOUSING
  const showHousing = () => {
    addBotMessage(
      'Ungalukku housing-la enna help venum akka? Pudhu veedu katta government assistance venuma, veedu vaanga help venuma, illa veedu sambandhamaana government scheme details venuma?'
    )
  }

  // WOMEN & FAMILY
  const showWomenFamily = () => {
    addBotMessage(
      'Ungalukku enna help venum akka? Women government schemes, child care support, maternity benefits, illa family welfare services pathi therinjukkanuma?'
    )
  }

  // UNKNOWN HELP
  const showUnknownHelp = () => {
    addBotMessage(
      'Parava illa akka! 😊 Naan ungalukku help panren. Neenga unga problem-ai simple-aa sollunga. Ungalukku enna government help kidaikkum-nu serndhu kandupidikkalam.'
    )
  }

  // SCHEME INFORMATION
  const showScheme = () => {
    addBotMessage(
      'Ungalukku enna help venum akka? Education, job, financial help, health, housing, illa women and family support pathi kelunga. Ungaloda problem-ai simple-aa sollunga, naan guide panren.'
    )
  }

  // ELIGIBILITY
  const showEligibility = () => {
    addBotMessage(
      'Vanakkam akka 👋 Ungalukku enna type help venum?'
    )
  }

  // DOCUMENTS
  const showDocuments = () => {
    addBotMessage(
      'Application-ku required documents situation-ai depend pannum. Official process-la required documents verify pannitu submit panna vendum.'
    )
  }

  // YES / NO
  const handleYes = () => {
    addBotMessage(
      'Ungalukku pregnancy registration complete aayiducha? Aama na YES, illana NO.'
    )
  }

  const handleNo = () => {
    addBotMessage(
      'Parava illa. Pregnancy registration complete pannradhukku Anganwadi worker or ASHA worker help pannalaam.'
    )
  }

  // VOICE INPUT
  const startVoice = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition

    if (!SpeechRecognition) {
      addBotMessage(
        'Voice input indha browser-la support aagala. Chrome browser use pannunga.'
      )
      return
    }

    const recognition = new SpeechRecognition()
    recognition.lang = 'ta-IN'
    recognition.continuous = false
    recognition.interimResults = false

    recognition.onresult = (event: any) => {
      const text = event.results[0][0].transcript
      setMessage(text)
    }

    recognition.onerror = () => {
      addBotMessage(
        'Voice puriyala. Konjam clear-aa pesunga.'
      )
    }

    recognition.start()
  }

  // SEND MESSAGE
  const sendMessage = () => {
    const text = message.trim()
    if (!text) return

    setMessages(prev => [...prev, `You: ${text}`])
    setMessage('')

    const lower = text.toLowerCase()

    setTimeout(() => {
      if (
        lower.includes('education') ||
        lower.includes('scholarship')
      ) {
        showEducation()
      } else if (
        lower.includes('job') ||
        lower.includes('skill')
      ) {
        showJobs()
      } else if (
        lower.includes('financial') ||
        lower.includes('money') ||
        lower.includes('business')
      ) {
        showFinancialHelp()
      } else if (
        lower.includes('health') ||
        lower.includes('hospital')
      ) {
        showHealth()
      } else if (
        lower.includes('housing') ||
        lower.includes('house')
      ) {
        showHousing()
      } else if (
        lower.includes('women') ||
        lower.includes('family') ||
        lower.includes('maternity')
      ) {
        showWomenFamily()
      } else if (
        lower.includes('scheme') ||
        lower.includes('pmmvy') ||
        lower.includes('திட்டம்')
      ) {
        showScheme()
      } else if (
        lower.includes('eligible') ||
        lower.includes('eligibility')
      ) {
        showEligibility()
      } else if (
        lower.includes('document')
      ) {
        showDocuments()
      } else {
        addBotMessage(
          'Ungalukku enna help venum akka? Education, job, financial help, health, housing, illa women and family support pathi kelunga.'
        )
      }
    }, 500)
  }

  // USER INTERFACE
  return (
    <div className="app">

      {/* HEADER */}
      <header className="header">
        <div className="logo">🌸 SRI AI</div>
        <div className="tagline">
          Simple help. Your language.
        </div>
      </header>

      {/* WELCOME SCREEN */}
      {!started ? (
        <main className="welcome">

          <div className="icon-circle">
            🤝
          </div>

          <h1>Vanakkam! 👋</h1>

          <p>
            Education, jobs, health, financial help matrum
            government services-ai easy-aa access panna
            <strong> SRI AI </strong>
            unga kooda irukku.
          </p>

          <button
            className="start-btn"
            onClick={startAssistant}
          >
            🎤 Start with SRI AI
          </button>

          <div className="features">
            <div>🗣️ Tamil Voice</div>
            <div>📋 Simple Steps</div>
            <div>🏛️ Government Schemes</div>
          </div>

        </main>
      ) : (

        /* CHAT SCREEN */
        <main className="chat-container">

          {/* CHAT HEADER */}
          <div className="chat-header">
            <div className="bot-icon">🌸</div>
            <div>
              <h2>SRI AI</h2>
              <span>● Ready to help</span>
            </div>
          </div>

          {/* MESSAGES */}
          <div className="messages">
            {messages.map((msg, index) => (
              <div className="message" key={index}>
                {msg}
              </div>
            ))}
          </div>

          {/* HELP CATEGORY BUTTONS */}
          <div className="quick-buttons">
            <button onClick={showEducation}>
              🎓 Education
            </button>

            <button onClick={showJobs}>
              💼 Job / Skills
            </button>

            <button onClick={showFinancialHelp}>
              💰 Financial Help
            </button>

            <button onClick={showHealth}>
              🏥 Health
            </button>

            <button onClick={showHousing}>
              🏠 Housing
            </button>

            <button onClick={showWomenFamily}>
              👩 Women & Family
            </button>

            <button onClick={showUnknownHelp}>
              🔍 I don't know
            </button>
          </div>

          {/* INPUT AREA */}
          <div className="input-area">
            <input
              type="text"
              value={message}
              placeholder="Type here..."
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  sendMessage()
                }
              }}
            />

            <button
              className="mic-btn"
              onClick={startVoice}
            >
              🎤
            </button>

            <button
              className="send-btn"
              onClick={sendMessage}
            >
              ➤
            </button>
          </div>

        </main>
      )}

      {/* FOOTER */}
      <footer>
        SRI AI • Making digital services easier
      </footer>

    </div>
  )
}

export default App