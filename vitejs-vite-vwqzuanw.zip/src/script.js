const welcomeScreen = document.getElementById("welcomeScreen");
const assistantScreen = document.getElementById("assistantScreen");
const chatBox = document.getElementById("chatBox");
const userInput = document.getElementById("userInput");


function startAssistant() {

  welcomeScreen.classList.add("hidden");
  assistantScreen.classList.remove("hidden");

}


/* Add message */

function addMessage(text, type) {

  const message = document.createElement("div");

  message.classList.add("message", type);

  message.innerHTML = text;

  chatBox.appendChild(message);

  chatBox.scrollTop = chatBox.scrollHeight;
}


/* Bot response */

function botMessage(text) {

  setTimeout(() => {

    addMessage(text, "bot");

  }, 300);

}


/* Scheme information */

function showScheme() {

  addMessage(
    "PMMVY scheme pathi therinjukanum",
    "user"
  );

  botMessage(`
    <b>PMMVY – Pradhan Mantri Matru Vandana Yojana</b>
    <br><br>

    Idhu pregnant women and lactating mothers-ku
    government maternity benefit scheme.
    <br><br>

    First child-ku eligible beneficiary-ku
    ₹5,000 benefit irukku.
    <br><br>

    Second child girl child-na
    ₹6,000 benefit irukku.
    <br><br>

    Naan unga eligibility check panna help panren.
  `);

}


/* Eligibility */

function checkEligibility() {

  addMessage(
    "Naan eligible-aa?",
    "user"
  );

  botMessage(`
    Seri akka 👍
    Namma simple-a check pannalam.
    <br><br>

    First question:
    <br><br>

    <b>Neenga pregnant-aa illa recently baby born aacha?</b>
    <br><br>

    <button onclick="answerPregnancy('yes')">
      Yes
    </button>

    <button onclick="answerPregnancy('no')">
      No
    </button>
  `);

}


function answerPregnancy(answer) {

  if (answer === "no") {

    botMessage(`
      PMMVY maternity benefit scheme.
      So pregnancy / recent childbirth-related
      eligibility irukkanum.
      <br><br>

      Exact eligibility-ku official government
      information check pannunga.
    `);

    return;
  }


  botMessage(`
    Super 👍
    <br><br>

    Next:
    <br><br>

    <b>
    Ungalukku PMMVY eligibility criteria-la
    edhavadhu one proof irukka?
    </b>

    <br><br>

    Example:
    <br>
    • MGNREGA Job Card
    <br>
    • e-Shram Card
    <br>
    • BPL ration card
    <br>
    • NFSA ration card
    <br>
    • SC/ST certificate
    <br>
    • Family income below ₹8 lakh
    <br>
    • Other listed categories
  `);

}


/* Documents */

function showDocuments() {

  addMessage(
    "Enna documents venum?",
    "user"
  );

  botMessage(`
    PMMVY application-ku required documents
    case/eligibility basis-ku depend aagum.
    <br><br>

    Commonly required information includes:
    <br><br>

    📄 Aadhaar
    <br>
    📄 MCP/RCHI card
    <br>
    📄 Bank/Post Office account details
    <br>
    📄 Mobile number
    <br>
    📄 Eligibility proof
    <br><br>

    Exact document requirement-ai official
    PMMVY portal-la verify pannunga.
  `);

}


/* Send text */

function sendMessage() {

  const text = userInput.value.trim();

  if (text === "") return;

  addMessage(text, "user");

  userInput.value = "";

  botMessage(
    "Purinjukitten akka 😊 Naan unga request-ai understand panni next step solla try panren."
  );

}


/* Enter key */

function handleEnter(event) {

  if (event.key === "Enter") {

    sendMessage();

  }

}


/* Voice */

function startVoice() {

  if (!("webkitSpeechRecognition" in window)) {

    botMessage(
      "Voice input indha browser-la support aagala. Text use pannunga."
    );

    return;
  }


  const recognition =
    new webkitSpeechRecognition();

  recognition.lang = "ta-IN";

  recognition.continuous = false;

  recognition.interimResults = false;


  recognition.start();


  botMessage(
    "🎤 Kekuren akka... pesunga."
  );


  recognition.onresult = function(event) {

    const transcript =
      event.results[0][0].transcript;

    userInput.value = transcript;

    sendMessage();

  };


  recognition.onerror = function() {

    botMessage(
      "Voice puriyala akka. Konjam clear-a marubadiyum pesunga."
    );

  };

}